from flask import Flask, request, jsonify
from multiprocessing import Process
from queue import Queue
import threading, time, os
from urllib.parse import urlparse

app = Flask(__name__)

task_queue = Queue()
current_job = None
queue_lock = threading.Lock()


# ====== HÀM GỐC CHẠY TOOL ======
def run_tool(video_url, target_views):
    # ⚠️ ĐỔI "your_script_filename" thành tên file Python gốc (không .py)
    from utils import start, get_machine_id  
    from multiprocessing import Manager, Lock

    parsed = urlparse(video_url)
    parts = parsed.path.split('/')
    if len(parts) < 4:
        print("❌ URL không hợp lệ!")
        return

    video_user = parts[1]
    video_id = parts[3]

    process_count = 6
    manager = Manager()
    shared_state = manager.Namespace()
    lock_local = Lock()

    # Biến trạng thái
    shared_state.device_id = None
    shared_state.iid = None
    shared_state.success_count = 0
    shared_state.cached_headers = None
    shared_state.cached_params_str = None
    shared_state.random_allowed = True
    shared_state.mode = "random"
    shared_state.fixed_device_id = None
    shared_state.fixed_iid = None
    shared_state.fail_count = 0
    shared_state.cached_gorgon = None
    shared_state.cached_ladon = None
    shared_state.cached_argus = None
    shared_state.cached_unix_timestamp = 0
    shared_state.cached_params_str = ""

    processes = []
    stop_flag = threading.Event()

    # Giám sát số view và dừng khi đạt target
    def monitor_views():
        while not stop_flag.is_set():
            time.sleep(2)
            if shared_state.success_count >= target_views:
                print(f"\n[🏁] {video_id} đã đạt {target_views} view — dừng tiến trình tăng view.")
                for p in processes:
                    if p.is_alive():
                        p.terminate()
                stop_flag.set()
                break

    threading.Thread(target=monitor_views, daemon=True).start()

    for _ in range(process_count):
        p = Process(target=start, args=(video_id, video_user, shared_state, lock_local))
        p.start()
        processes.append(p)

    # Chờ tất cả process kết thúc
    for p in processes:
        p.join()

    print(f"[✅] Hoàn tất video: {video_id}")


# ====== WORKER CHÍNH (XỬ LÝ HÀNG CHỜ TUẦN TỰ) ======
def worker_loop():
    global current_job
    while True:
        url, views = task_queue.get(block=True)
        with queue_lock:
            current_job = (url, views)

        print(f"\n[▶️] Bắt đầu chạy link: {url} ({views} view)\n")
        try:
            run_tool(url, views)
        except Exception as e:
            print(f"[❌] Lỗi khi chạy link {url}: {e}")
        finally:
            with queue_lock:
                current_job = None
            task_queue.task_done()
            print(f"[➡️] Chuyển sang link kế tiếp nếu có...\n")


# Chạy worker nền
threading.Thread(target=worker_loop, daemon=True).start()


# ====== API /run ======
@app.route("/run", methods=["POST"])
def run_task():
    data = request.get_json()
    if not data or "url" not in data or "views" not in data:
        return jsonify({"error": "Thiếu tham số url hoặc views"}), 400

    url = data["url"]
    target_views = int(data["views"])

    with queue_lock:
        task_queue.put((url, target_views))
        position = task_queue.qsize()

    if current_job is None and position == 1:
        status = "started"
    else:
        status = "queued"

    return jsonify({
        "status": status,
        "message": f"Đã nhận yêu cầu. Vị trí trong hàng chờ: {position}",
        "url": url,
        "views": target_views
    })


@app.route("/status", methods=["GET"])
def status():
    with queue_lock:
        status = "idle"
        if current_job is not None:
            status = "running"
    return jsonify({
        "status": status,
        "queue_length": task_queue.qsize(),
        "current": current_job
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
