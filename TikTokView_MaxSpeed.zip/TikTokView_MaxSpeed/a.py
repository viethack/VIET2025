import requests, json

url = "http://127.0.0.1:5000/run"
payload = {
    "url": "https://www.tiktok.com/@chammi.23396/video/7566352786917477639",
    "views": 10000
}
headers = {"Content-Type": "application/json"}

try:
    r = requests.post(url, headers=headers, data=json.dumps(payload))
    print(f"HTTP {r.status_code}")
    print(r.text)
    r.raise_for_status()
except requests.exceptions.RequestException as e:
    print(f"Lỗi: {e}")
